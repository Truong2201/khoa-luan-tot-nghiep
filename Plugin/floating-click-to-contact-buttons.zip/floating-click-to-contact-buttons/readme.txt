﻿== Floating Click to Contact Buttons ==
Contributors: Phuc Nhan Nguyen
Donate link: https://mevivu.com
Tags: call button, quick call button, call now button, call to action, click to call, click to contact, contact all in one, floating action buttons, FAB
Requires at least: 3.5
Tested up to: 5.3.2
Stable tag: 1.2.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0

Tạo các nút gọi, nút chat Zalo, nút Chat messenger, nút để lại thông tin để tư vấn, nút chỉ đường. Trình bày các nút đẹp mắt ở góc phải dưới màn hình, ẩn các nút, khi bấm vào mới hiện ra. Tạo kênh liên hệ nhanh chóng và tiện lợi để quảng cáo web hiệu quả.

== Description ==
Đây là Plugin tạo các nút liên hệ tất cả chỉ trong một. Bao gồm nút Gọi ngay, nút chat zalo, nút chat messenger, nút để lại thông tin tư vấn, nút chỉ đường, nút tawkto. Ẩn các nút khi bấm vào mới hiện ra, hiệu ứng mượt. Trình bày gọn gàng.

Chúng ta có thể thay đổi số điện thoại gọi đến, chữ trên nút gọi. 
Copy và Dán Mã code của TawkTo vào ổ Tawkto Code để hiện ra Chat TawkTo.
Copy tên rút gọn của Fanpage Facebook vào ô Page ID để có chức năng Chat Messenger. Ví dụ: https://facebook.com/abc. Bạn ghi vào ô Page ID: abc.
Ghi số điện thoại Zalo để chức năng Chat Zalo hoạt động.
Copy đường toàn bộ Link Google Map để liên kết đến Google Map. Ví dụ: https://www.google.com/maps/place/Mevivu+Technology/@10.8397441,106.6471742,15z/data=!4m2!3m1!1s0x0:0x73a2be67d900f176?sa=X&ved=2ahUKEwj16sflk-7mAhVX6nMBHZz6AdoQ_BIwDXoECAoQCA. Để có được đường link này bạn vào Google Map và Search như bình thường, sau đó Copy đường link sau khi đã search.
Để chức năng Để lại thông tin tư vấn hoạt động. Ta cần phải Cài Contact Form 7. Sau đó vào tạo 1 Form liên hệ và lấy Shortcode ghi vào ô Shortcode Contact Form 7.
Nếu ô nào trống thì nút đó sẽ không hiện ra.

== Installation ==
1. Upload thư mục \'floating-click-to-contact-buttons\' vào wp-content/plugins
1. Kích hoạt plugin trong khu vực Plugins -> Installed Plugins
1. Vào mục Floating Contact Buttons bên trái Menu để cài đặt.

== Frequently Asked Questions ==
= Tôi có thể ẩn các ô thông tin kế bên nút không. Chỉ hiện ra nút thôi để đỡ rối.
Hoàn toàn được. Bạn stick vào ô Ẩn chữ chú thích kế bên nút.


== Screenshots ==
1. Menu thiết lập các nút.
2. Cái đặt các thông tin của các nút.
3. Các nút hiện ra trên Websigte.