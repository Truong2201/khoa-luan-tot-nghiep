<div class="itsec-pwls-login-header">
	<h2 class="itsec-pwls-login__title">
		<?php printf( esc_html__( 'Logging in as %s', 'it-l10n-ithemes-security-pro' ), $username ) ?>
	</h2>
</div>
