<?php

return [
	'title' => __( 'Passwordless Login', 'it-l10n-ithemes-security-pro' ),
];
