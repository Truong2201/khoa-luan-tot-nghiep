<?php

return [
	'title' => __( 'Version Management', 'it-l10n-ithemes-security-pro' ),
];
