<?php

return [
	'title' => __( 'Grade Report', 'it-l10n-ithemes-security-pro' ),
];
