<?php

require_once( 'class-itsec-online-files.php' );
require_once( dirname( __FILE__ ) . '/class-itsec-online-files-utility.php' );
$itsec_online_files = new ITSEC_Online_Files();
$itsec_online_files->run();
