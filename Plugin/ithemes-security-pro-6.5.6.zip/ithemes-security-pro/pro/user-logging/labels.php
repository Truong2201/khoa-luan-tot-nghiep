<?php

return [
	'title' => __( 'User Logging', 'it-l10n-ithemes-security-pro' ),
];
